
    for ((i = 0; i >= 0; i++))
    do
      ./simulation control_file.txt 
    done
